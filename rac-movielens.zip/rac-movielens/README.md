# RAC for MovieLens (Reproducible)

This repository packages the MovieLens experiment for the risk-averse conformal (RAC) method.

## Environment

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## Quickstart

```bash
python experiments/movielens/train.py --epochs 10
python experiments/movielens/rac_eval.py --alpha 0.05
python experiments/movielens/baselines.py --alpha 0.05
```

Results go to `artifacts/movielens/`.

The original notebook is preserved at `experiments/movielens/notebook_flattened.py`
and the literal `.ipynb` is in `notebooks/`.

Generated on 2025-10-23.
