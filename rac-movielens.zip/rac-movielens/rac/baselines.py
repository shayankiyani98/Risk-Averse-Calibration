# Baseline decision policies

import os
import requests
import zipfile
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import random
from collections import defaultdict, Counter
    from collections import defaultdict
from collections import Counter
import math
from tqdm import tqdm
    from tqdm import tqdm  # If you prefer to track progress
import matplotlib.pyplot as plt


# --- Auto-extracted block ---
# From cell 3
import torch
import numpy as np

def evaluate_baseline_best_response(model, test_loader, alpha, device='cpu'):
    """
    Baseline: for each sample, pick the action (recommend/not recommend) that 
    maximizes the *expected utility* given the model's predicted probabilities.
    
    Utility function (as in original code):
      - If a=0 (not recommend), u=0.
      - If a=1 (recommend), u = (rating in [1..5]) - 3.
      
    Reports:
      - Average utility
      - Percentage recommended by true rating
      - Utility histogram (empirical PDF)
      - alpha-quantile of realized utilities
    """
    model.eval()
    model.to(device)
    
    # Keep track of total utility and sample count
    total_utility = 0.0
    total_samples = 0
    utility_values = []
    
    # rating_counts[r], recommend_counts[r] for r in [1..5]
    rating_counts = {r: 0 for r in [1, 2, 3, 4, 5]}
    recommend_counts = {r: 0 for r in [1, 2, 3, 4, 5]}
    
    # Utility histogram for possible realized utilities in {-2, -1, 0, 1, 2}
    # (since u=0 if not recommend, or u=(r-3) if recommend)
    utility_histogram = {u: 0 for u in [-2, -1, 0, 1, 2]}
    
    with torch.no_grad():
        for batch in test_loader:
            (user_ids, item_ids, side_info), y_true_class = batch
            user_ids   = user_ids.to(device)
            item_ids   = item_ids.to(device)
            side_info  = side_info.to(device)
            y_true_class = y_true_class.to(device)  # rating in [0..4], so "true rating" = y_true_class+1 in [1..5]
            
            # Forward pass -> logits -> convert to probabilities
            logits = model(user_ids, item_ids, side_info)  # shape (batch_size, 5)
            probs  = torch.softmax(logits, dim=1)          # shape (batch_size, 5)
            
            batch_size = y_true_class.shape[0]
            
            for i in range(batch_size):
                # True rating is in [1..5]
                r_true = int(y_true_class[i].item()) + 1
                rating_counts[r_true] += 1
                total_samples += 1
                
                # Probability vector for the 5 possible ratings
                p_vec = probs[i]  # shape (5,)
                # We'll move it to CPU numpy for easier handling, if needed
                p_np = p_vec.detach().cpu().numpy()
                
                # For each action a in {0,1}, compute E[u(a)] = sum_{r=1..5} p[r-1]*u(a, r)
                # where u(0,r)=0 and u(1,r)=r-3
                # Let's define a small function for this local case:
                def exp_utility(a):
                    e_val = 0.0
                    for rating_idx in range(5):  # rating_idx=0..4 => r=rating_idx+1
                        r = rating_idx + 1
                        if a == 1:
                            # recommend => utility = r - 3
                            e_val += p_np[rating_idx] * (r - 3)
                        else:
                            # a=0 => no recommend => utility=0
                            e_val += p_np[rating_idx] * 0.0
                    return e_val
                
                # Decide best action
                exp_u_0 = exp_utility(a=0)
                exp_u_1 = exp_utility(a=1)
                if exp_u_1 > exp_u_0:
                    final_action = 1  # recommend
                else:
                    final_action = 0  # not recommend
                
                # Realized utility with the true rating r_true
                if final_action == 1:
                    # recommend => utility = r_true - 3
                    u_val = r_true - 3
                    recommend_counts[r_true] += 1
                else:
                    # not recommend => utility = 0
                    u_val = 0
                
                total_utility += u_val
                utility_values.append(u_val)
                
                # Update utility histogram if it's in [-2, -1, 0, 1, 2]
                if u_val in utility_histogram:
                    utility_histogram[u_val] += 1

    # Averages
    avg_utility = total_utility / total_samples if total_samples > 0 else 0.0
    
    # Percentage recommended by true rating
    recommend_percents = {}
    for r in [1, 2, 3, 4, 5]:
        if rating_counts[r] > 0:
            perc = 100.0 * recommend_counts[r] / rating_counts[r]
        else:
            perc = 0.0
        recommend_percents[r] = perc
    
    # Convert histogram to PDF
    total_util_count = sum(utility_histogram.values())
    utility_pdf = {}
    for u_val, count in utility_histogram.items():
        if total_util_count > 0:
            utility_pdf[u_val] = count / total_util_count
        else:
            utility_pdf[u_val] = 0.0
    
    # alpha-Quantile of realized utilities
    sorted_utils = sorted(utility_values)
    alpha_quantile = float(np.quantile(sorted_utils, alpha)) if len(sorted_utils) > 0 else 0.0
    
    print("=== Baseline: Best Response (Expected Utility) ===")
    print(f"Average Utility = {avg_utility:.4f}")
    for r in [1, 2, 3, 4, 5]:
        print(f"  True rating {r}: recommended {recommend_percents[r]:.2f}% of the time")
    
    print("Utility Histogram (Empirical PDF):")
    for u_val in sorted(utility_pdf.keys()):
        print(f"  Utility {u_val}: {utility_pdf[u_val]:.4f}")
    
    print(f"Alpha-Quantile ({alpha*100:.1f}%): {alpha_quantile:.4f}")
    
    return avg_utility, recommend_percents, utility_pdf, alpha_quantile

# --- Auto-extracted block ---
# From cell 5
import torch
import numpy as np

###############################################################################
# 1) Compute the conformal threshold T on the calibration set
###############################################################################

def compute_conformal_threshold(model, calib_loader, alpha=0.2, device='cpu'):
    """
    - model: classification model with logits of shape (batch_size, 5)
    - calib_loader: DataLoader for the calibration set
    - alpha=0.2 => coverage ~80%
    Returns: threshold T
    """
    model.eval()
    model.to(device)
    
    nonconformity_scores = []
    
    with torch.no_grad():
        for batch in calib_loader:
            # batch => ([user_ids, item_ids, side_info], y_class)
            #   y_class in {0..4}
            (user_ids, item_ids, side_info), y_class = batch
            
            user_ids  = user_ids.to(device)
            item_ids  = item_ids.to(device)
            side_info = side_info.to(device)
            y_class   = y_class.to(device)
            
            # Forward => logits => softmax => probabilities
            logits = model(user_ids, item_ids, side_info)  # (batch_size, 5)
            probs = torch.softmax(logits, dim=1)           # shape (batch_size,5)
            
            # For each i in batch, nonconformity = 1 - p_{y_i}(x_i)
            # y_class[i] is an integer 0..4
            for i in range(len(y_class)):
                true_c = y_class[i].item()        # 0..4
                p_true = probs[i, true_c].item()  # predicted probability for the correct class
                score = 1.0 - p_true
                nonconformity_scores.append(score)
    
    # Convert to numpy
    nonconformity_scores = np.array(nonconformity_scores)
    
    # Compute the (1-alpha) quantile => T
    # e.g. np.quantile(nonconformity_scores, 1-alpha)
    # We'll use method='higher' to be conservative, or you can choose method='linear'.
    T = float(np.quantile(nonconformity_scores, 1 - alpha, method='higher'))
    
    return T

###############################################################################
# 2) Evaluate the risk-averse policy on test set
###############################################################################

import torch
import numpy as np
from collections import defaultdict, Counter

def evaluate_conformal_policy(
    model, 
    test_loader, 
    T, 
    u, 
    alpha, 
    device='cpu'
):
    """
    - model: classification model
    - test_loader: DataLoader for test set
    - T: threshold from conformal calibration
    - u: utility function: u(action, c) -> real
    - alpha: quantile value for utility histogram
    - device: 'cpu' or 'cuda'
    
    Policy (unchanged):
      1) For each sample, form S_indices = { c': p[c'] >= 1 - T }.
      2) If {0..2} intersect S_indices, utility = u(0, c) (not recommended),
         else utility = u(1, c) (recommended).
    
    Reports:
      - coverage: fraction of times c in S_indices
      - avg_utility
      - recommend_percents
      - utility_histogram & PDF
      - alpha-quantile
      - avg_maxmin (set to 0.0 here, for consistency with other baselines)
    """

    model.eval()
    model.to(device)
    
    total_utility = 0.0
    total_maxmin = 0.0
    total_samples = 0
    utility_values = []

    # Coverage counter
    coverage_count = 0

    # Track counts by true rating [1..5]
    rating_counts = {r: 0 for r in [1, 2, 3, 4, 5]}
    recommend_counts = {r: 0 for r in [1, 2, 3, 4, 5]}
    
    # We'll keep a histogram of possible utilities.
    # If you expect them only in [-2, -1, 0, 1, 2], you can keep that fixed.
    # Otherwise, let's use a Counter to track any realized utility.
    from collections import defaultdict
    utility_histogram = defaultdict(int)
    
    with torch.no_grad():
        for batch in test_loader:
            (user_ids, item_ids, side_info), y_class = batch
            user_ids  = user_ids.to(device)
            item_ids  = item_ids.to(device)
            side_info = side_info.to(device)
            y_class   = y_class.to(device)  # in [0..4]
            
            logits = model(user_ids, item_ids, side_info)
            probs = torch.softmax(logits, dim=1)  # shape: (batch_size, 5)
            batch_size = y_class.shape[0]
            
            for i in range(batch_size):
                c = int(y_class[i].item())  # true class in [0..4]
                r = c + 1  # true rating in [1..5]
                rating_counts[r] += 1
                total_samples += 1
                
                # Form S_indices
                p = probs[i]  # shape (5,)
                cutoff = 1.0 - T
                S_indices = (p >= cutoff).nonzero(as_tuple=True)[0].tolist()  # list of class indices

                # Coverage check
                if c in S_indices:
                    coverage_count += 1

                # Realized utility
                if any(x in [0,1,2] for x in S_indices):
                    # Not recommend
                    utility = u(0, c)
                    total_maxmin+=0
                elif 3 in S_indices:
                    # Recommend
                    utility = u(1, c)
                    recommend_counts[r] += 1
                    total_maxmin+=1
                else:
                    utility = u(1, c)
                    recommend_counts[r] += 1
                    total_maxmin+=2
                
                total_utility += utility
                utility_values.append(utility)
                utility_histogram[utility] += 1
    
    # 1) Coverage
    coverage = coverage_count / total_samples if total_samples > 0 else 0.0
    
    # 2) Average utility
    avg_utility = total_utility / total_samples if total_samples > 0 else 0.0
    avg_maxmin = total_maxmin / total_samples if total_samples > 0 else 0.0
    
    # 3) Recommendation percentages
    recommend_percents = {}
    for r in [1, 2, 3, 4, 5]:
        if rating_counts[r] > 0:
            recommend_percents[r] = 100.0 * recommend_counts[r] / rating_counts[r]
        else:
            recommend_percents[r] = 0.0
    
    # 4) Convert histogram to empirical PDF
    total_count = sum(utility_histogram.values())
    utility_pdf = {}
    for val, cnt in utility_histogram.items():
        if total_count > 0:
            utility_pdf[val] = cnt / total_count
        else:
            utility_pdf[val] = 0.0
    
    # 6) Print results
    print("=== Conformal Policy (risk-averse) ===")
    print(f"Threshold T = {T:.4f}, alpha={alpha}")
    print(f"Coverage: {coverage:.3f}")
    print(f"Average Utility: {avg_utility:.4f}\n")
    print("Recommend % by TRUE rating:")
    for r in [1, 2, 3, 4, 5]:
        print(f"  Rating={r}: recommended {recommend_percents[r]:.2f}%")
    
    print("\nUtility Histogram (Empirical Distribution):")
    for val in sorted(utility_pdf.keys()):
        print(f"  Utility {val}: {utility_pdf[val]:.4f}")
    # 7) Return a dictionary of results
    results_dict = {
        "coverage": coverage,
        "avg_utility": avg_utility,
        "recommend_percents": recommend_percents,
        "utility_histogram": dict(utility_histogram),
        "utility_pdf": utility_pdf,
        "avg_maxmin_value": avg_maxmin  # no max-min logic here, but included for consistency
    }
    
    return results_dict

###############################################################################
# USAGE EXAMPLE
###############################################################################

# You can run something like:
def example_utility_fn(a, y):
    # a=0 => "not recommend", a=1 => "recommend"
    if a == 0:
        return 0.0
    else:
        # a=1 => let's define u = (y-2)
        return float(y - 2)
    
alpha = 0.2
T = compute_conformal_threshold(model, calib_loader, alpha=alpha, device=device)
results= evaluate_conformal_policy(model, test_loader, T, example_utility_fn, 0.1, device=device)

# --- Auto-extracted block ---
# From cell 5
import torch
import numpy as np

###############################################################################
# 1) Compute the conformal threshold T on the calibration set
###############################################################################

def compute_conformal_threshold(model, calib_loader, alpha=0.2, device='cpu'):
    """
    - model: classification model with logits of shape (batch_size, 5)
    - calib_loader: DataLoader for the calibration set
    - alpha=0.2 => coverage ~80%
    Returns: threshold T
    """
    model.eval()
    model.to(device)
    
    nonconformity_scores = []
    
    with torch.no_grad():
        for batch in calib_loader:
            # batch => ([user_ids, item_ids, side_info], y_class)
            #   y_class in {0..4}
            (user_ids, item_ids, side_info), y_class = batch
            
            user_ids  = user_ids.to(device)
            item_ids  = item_ids.to(device)
            side_info = side_info.to(device)
            y_class   = y_class.to(device)
            
            # Forward => logits => softmax => probabilities
            logits = model(user_ids, item_ids, side_info)  # (batch_size, 5)
            probs = torch.softmax(logits, dim=1)           # shape (batch_size,5)
            
            # For each i in batch, nonconformity = 1 - p_{y_i}(x_i)
            # y_class[i] is an integer 0..4
            for i in range(len(y_class)):
                true_c = y_class[i].item()        # 0..4
                p_true = probs[i, true_c].item()  # predicted probability for the correct class
                score = 1.0 - p_true
                nonconformity_scores.append(score)
    
    # Convert to numpy
    nonconformity_scores = np.array(nonconformity_scores)
    
    # Compute the (1-alpha) quantile => T
    # e.g. np.quantile(nonconformity_scores, 1-alpha)
    # We'll use method='higher' to be conservative, or you can choose method='linear'.
    T = float(np.quantile(nonconformity_scores, 1 - alpha, method='higher'))
    
    return T

###############################################################################
# 2) Evaluate the risk-averse policy on test set
###############################################################################

import torch
import numpy as np
from collections import defaultdict, Counter

def evaluate_conformal_policy(
    model, 
    test_loader, 
    T, 
    u, 
    alpha, 
    device='cpu'
):
    """
    - model: classification model
    - test_loader: DataLoader for test set
    - T: threshold from conformal calibration
    - u: utility function: u(action, c) -> real
    - alpha: quantile value for utility histogram
    - device: 'cpu' or 'cuda'
    
    Policy (unchanged):
      1) For each sample, form S_indices = { c': p[c'] >= 1 - T }.
      2) If {0..2} intersect S_indices, utility = u(0, c) (not recommended),
         else utility = u(1, c) (recommended).
    
    Reports:
      - coverage: fraction of times c in S_indices
      - avg_utility
      - recommend_percents
      - utility_histogram & PDF
      - alpha-quantile
      - avg_maxmin (set to 0.0 here, for consistency with other baselines)
    """

    model.eval()
    model.to(device)
    
    total_utility = 0.0
    total_maxmin = 0.0
    total_samples = 0
    utility_values = []

    # Coverage counter
    coverage_count = 0

    # Track counts by true rating [1..5]
    rating_counts = {r: 0 for r in [1, 2, 3, 4, 5]}
    recommend_counts = {r: 0 for r in [1, 2, 3, 4, 5]}
    
    # We'll keep a histogram of possible utilities.
    # If you expect them only in [-2, -1, 0, 1, 2], you can keep that fixed.
    # Otherwise, let's use a Counter to track any realized utility.
    from collections import defaultdict
    utility_histogram = defaultdict(int)
    
    with torch.no_grad():
        for batch in test_loader:
            (user_ids, item_ids, side_info), y_class = batch
            user_ids  = user_ids.to(device)
            item_ids  = item_ids.to(device)
            side_info = side_info.to(device)
            y_class   = y_class.to(device)  # in [0..4]
            
            logits = model(user_ids, item_ids, side_info)
            probs = torch.softmax(logits, dim=1)  # shape: (batch_size, 5)
            batch_size = y_class.shape[0]
            
            for i in range(batch_size):
                c = int(y_class[i].item())  # true class in [0..4]
                r = c + 1  # true rating in [1..5]
                rating_counts[r] += 1
                total_samples += 1
                
                # Form S_indices
                p = probs[i]  # shape (5,)
                cutoff = 1.0 - T
                S_indices = (p >= cutoff).nonzero(as_tuple=True)[0].tolist()  # list of class indices

                # Coverage check
                if c in S_indices:
                    coverage_count += 1

                # Realized utility
                if any(x in [0,1,2] for x in S_indices):
                    # Not recommend
                    utility = u(0, c)
                    total_maxmin+=0
                elif 3 in S_indices:
                    # Recommend
                    utility = u(1, c)
                    recommend_counts[r] += 1
                    total_maxmin+=1
                else:
                    utility = u(1, c)
                    recommend_counts[r] += 1
                    total_maxmin+=2
                
                total_utility += utility
                utility_values.append(utility)
                utility_histogram[utility] += 1
    
    # 1) Coverage
    coverage = coverage_count / total_samples if total_samples > 0 else 0.0
    
    # 2) Average utility
    avg_utility = total_utility / total_samples if total_samples > 0 else 0.0
    avg_maxmin = total_maxmin / total_samples if total_samples > 0 else 0.0
    
    # 3) Recommendation percentages
    recommend_percents = {}
    for r in [1, 2, 3, 4, 5]:
        if rating_counts[r] > 0:
            recommend_percents[r] = 100.0 * recommend_counts[r] / rating_counts[r]
        else:
            recommend_percents[r] = 0.0
    
    # 4) Convert histogram to empirical PDF
    total_count = sum(utility_histogram.values())
    utility_pdf = {}
    for val, cnt in utility_histogram.items():
        if total_count > 0:
            utility_pdf[val] = cnt / total_count
        else:
            utility_pdf[val] = 0.0
    
    # 6) Print results
    print("=== Conformal Policy (risk-averse) ===")
    print(f"Threshold T = {T:.4f}, alpha={alpha}")
    print(f"Coverage: {coverage:.3f}")
    print(f"Average Utility: {avg_utility:.4f}\n")
    print("Recommend % by TRUE rating:")
    for r in [1, 2, 3, 4, 5]:
        print(f"  Rating={r}: recommended {recommend_percents[r]:.2f}%")
    
    print("\nUtility Histogram (Empirical Distribution):")
    for val in sorted(utility_pdf.keys()):
        print(f"  Utility {val}: {utility_pdf[val]:.4f}")
    # 7) Return a dictionary of results
    results_dict = {
        "coverage": coverage,
        "avg_utility": avg_utility,
        "recommend_percents": recommend_percents,
        "utility_histogram": dict(utility_histogram),
        "utility_pdf": utility_pdf,
        "avg_maxmin_value": avg_maxmin  # no max-min logic here, but included for consistency
    }
    
    return results_dict

###############################################################################
# USAGE EXAMPLE
###############################################################################

# You can run something like:
def example_utility_fn(a, y):
    # a=0 => "not recommend", a=1 => "recommend"
    if a == 0:
        return 0.0
    else:
        # a=1 => let's define u = (y-2)
        return float(y - 2)
    
alpha = 0.2
T = compute_conformal_threshold(model, calib_loader, alpha=alpha, device=device)
results= evaluate_conformal_policy(model, test_loader, T, example_utility_fn, 0.1, device=device)

# --- Auto-extracted block ---
# From cell 7
import torch
import numpy as np

def compute_conformal_threshold_newscore(model, calib_loader, alpha=0.2, device='cpu'):
    """
    Computes threshold T for the new non-conformity score:
      score(x, y) = sum_{y' != y : p(y') > p(y)} p(y')
    
    Steps:
      1) For each sample in calib_loader, compute probabilities p(y').
      2) Let the true class = y_class in [0..4].
         The score = sum of p(y') for all y' s.t. p(y') > p(y_class).
      3) Collect all scores, pick the (1-alpha)-quantile => T.
    """
    model.eval()
    model.to(device)
    
    nonconformity_scores = []
    
    with torch.no_grad():
        for batch in calib_loader:
            (user_ids, item_ids, side_info), y_class = batch
            user_ids   = user_ids.to(device)
            item_ids   = item_ids.to(device)
            side_info  = side_info.to(device)
            y_class    = y_class.to(device)  # in [0..4]
            
            logits = model(user_ids, item_ids, side_info)
            probs  = torch.softmax(logits, dim=1)  # shape (batch_size, 5)
            
            batch_size = y_class.shape[0]
            for i in range(batch_size):
                c = int(y_class[i].item())    # the true class
                p_true = probs[i, c].item()   # p(y_class)
                
                # Non-conformity score: sum of p[y'] for y' != c where p[y'] > p[c]
                score = 0.0
                for y_prime in range(5):
                    if y_prime != c:
                        p_yp = probs[i, y_prime].item()
                        if p_yp > p_true:
                            score += p_yp
                nonconformity_scores.append(score)
    
    # Convert to numpy and pick the (1-alpha) quantile
    nonconformity_scores = np.array(nonconformity_scores)
    T = float(np.quantile(nonconformity_scores, 1 - alpha, method='higher'))
    
    return T

import torch
import numpy as np
from collections import Counter

def evaluate_conformal_policy_newscore(
    model, 
    test_loader, 
    T, 
    u, 
    device='cpu'
):
    """
    - model: classification model
    - test_loader: DataLoader returning ([u, i, side_info], y_class)
    - T: threshold from the new non-conformity definition
    - u: utility function with signature u(action, c)
    - device: 'cpu' or 'cuda'

    Policy (unchanged):
      1) For each x, compute S(x) = { c' : score(x, c') <= T },
         where score(x, c') = sum_{c'' != c'} p_c''(x) for c'' s.t. p_c''(x) > p_c'(x).
      2) If {0 or 1} or 2 in S(x) => do NOT recommend
         Else if 3 in S(x) => recommend => total_maxmin += 1
         Else => recommend => total_maxmin += 2
         Realized utility is set accordingly.

    We now also:
      - Check coverage: (true_label in S(x))
      - Track a histogram of realized utilities
      - Return coverage, avg_utility, avg_maxmin, recommend% by rating, plus utility histogram
    """
    model.eval()
    model.to(device)
    
    total_utility = 0.0
    total_maxmin = 0.0
    total_samples = 0
    
    # Coverage count
    coverage_count = 0
    
    # For realized utilities, create a histogram. We don't know the possible range,
    # but let's store them in a Counter, which can handle any integer or float.
    from collections import defaultdict
    utility_histogram = defaultdict(int)
    utility_values = []

    # rating_counts[r], recommend_counts[r] for r in [1..5]
    rating_counts = {r: 0 for r in range(1, 6)}
    recommend_counts = {r: 0 for r in range(1, 6)}
    
    with torch.no_grad():
        for batch in test_loader:
            (user_ids, item_ids, side_info), y_class = batch
            user_ids = user_ids.to(device)
            item_ids = item_ids.to(device)
            side_info = side_info.to(device)
            y_class   = y_class.to(device)  # in [0..4]
            
            # 1) Compute probabilities
            logits = model(user_ids, item_ids, side_info)
            probs  = torch.softmax(logits, dim=1)  # (batch_size, 5)
            
            batch_size = y_class.shape[0]
            
            for i in range(batch_size):
                c = int(y_class[i].item())  # true class in [0..4]
                r = c + 1                   # true rating in [1..5]
                rating_counts[r] += 1
                total_samples += 1
                
                # 2) Build S(x)
                p_vec = probs[i]  # shape (5,)
                S_indices = []
                for cprime in range(5):
                    p_cprime = p_vec[cprime].item()
                    score_cp = 0.0
                    for c2 in range(5):
                        if c2 != cprime:
                            p_c2 = p_vec[c2].item()
                            if p_c2 > p_cprime:
                                score_cp += p_c2
                    if score_cp <= T:
                        S_indices.append(cprime)
                
                # 3) Coverage check
                if c in S_indices:
                    coverage_count += 1
                
                # 4) Decide recommended / not recommended 
                #    and compute realized utility + maxmin 
                if (0 in S_indices) or (1 in S_indices) or (2 in S_indices):
                    # do NOT recommend
                    utility = u(0, c)
                    total_maxmin += 0
                elif 3 in S_indices:
                    # recommend => utility = (c+1) - 3 = c - 2
                    utility = u(1, c)
                    total_maxmin += 1
                    recommend_counts[r] += 1
                else:
                    utility = u(1, c)
                    total_maxmin += 2
                    recommend_counts[r] += 1
                
                total_utility += utility
                utility_values.append(utility)
                utility_histogram[utility] += 1

    # 5) Summaries
    coverage = coverage_count / total_samples if total_samples > 0 else 0.0
    avg_utility = total_utility / total_samples if total_samples > 0 else 0.0
    avg_maxmin = total_maxmin / total_samples if total_samples > 0 else 0.0
    
    recommend_percents = {}
    for r in range(1, 6):
        if rating_counts[r] > 0:
            recommend_percents[r] = 100.0 * recommend_counts[r] / rating_counts[r]
        else:
            recommend_percents[r] = 0.0
    
    # Convert histogram to PDF
    total_hist_count = sum(utility_histogram.values())
    utility_pdf = {}
    for val, cnt in utility_histogram.items():
        if total_hist_count > 0:
            utility_pdf[val] = cnt / total_hist_count
        else:
            utility_pdf[val] = 0.0
    
    # Print summary
    print("=== Conformal Policy (newscore) ===")
    print(f"Threshold T = {T:.4f}")
    print(f"Coverage = {coverage:.3f}")
    print(f"Average Utility = {avg_utility:.4f}")
    print(f"Average Max-Min Value = {avg_maxmin:.4f}\n")
    
    print("Recommend % by TRUE rating:")
    for r in [1, 2, 3, 4, 5]:
        print(f"  Rating={r}: recommended {recommend_percents[r]:.2f}%")
    
    print("\nUtility Histogram (Empirical Distribution):")
    for val in sorted(utility_pdf.keys()):
        print(f"  Utility {val}: {utility_pdf[val]:.4f}")
    
    # Return dictionary
    results_dict = {
        "coverage": coverage,
        "avg_utility": avg_utility,
        "avg_maxmin_value": avg_maxmin,
        "recommend_percents": recommend_percents,
        "utility_histogram": dict(utility_histogram),
        "utility_pdf": utility_pdf
    }
    return results_dict

# --- Auto-extracted block ---
# From cell 7
import torch
import numpy as np

def compute_conformal_threshold_newscore(model, calib_loader, alpha=0.2, device='cpu'):
    """
    Computes threshold T for the new non-conformity score:
      score(x, y) = sum_{y' != y : p(y') > p(y)} p(y')
    
    Steps:
      1) For each sample in calib_loader, compute probabilities p(y').
      2) Let the true class = y_class in [0..4].
         The score = sum of p(y') for all y' s.t. p(y') > p(y_class).
      3) Collect all scores, pick the (1-alpha)-quantile => T.
    """
    model.eval()
    model.to(device)
    
    nonconformity_scores = []
    
    with torch.no_grad():
        for batch in calib_loader:
            (user_ids, item_ids, side_info), y_class = batch
            user_ids   = user_ids.to(device)
            item_ids   = item_ids.to(device)
            side_info  = side_info.to(device)
            y_class    = y_class.to(device)  # in [0..4]
            
            logits = model(user_ids, item_ids, side_info)
            probs  = torch.softmax(logits, dim=1)  # shape (batch_size, 5)
            
            batch_size = y_class.shape[0]
            for i in range(batch_size):
                c = int(y_class[i].item())    # the true class
                p_true = probs[i, c].item()   # p(y_class)
                
                # Non-conformity score: sum of p[y'] for y' != c where p[y'] > p[c]
                score = 0.0
                for y_prime in range(5):
                    if y_prime != c:
                        p_yp = probs[i, y_prime].item()
                        if p_yp > p_true:
                            score += p_yp
                nonconformity_scores.append(score)
    
    # Convert to numpy and pick the (1-alpha) quantile
    nonconformity_scores = np.array(nonconformity_scores)
    T = float(np.quantile(nonconformity_scores, 1 - alpha, method='higher'))
    
    return T

import torch
import numpy as np
from collections import Counter

def evaluate_conformal_policy_newscore(
    model, 
    test_loader, 
    T, 
    u, 
    device='cpu'
):
    """
    - model: classification model
    - test_loader: DataLoader returning ([u, i, side_info], y_class)
    - T: threshold from the new non-conformity definition
    - u: utility function with signature u(action, c)
    - device: 'cpu' or 'cuda'

    Policy (unchanged):
      1) For each x, compute S(x) = { c' : score(x, c') <= T },
         where score(x, c') = sum_{c'' != c'} p_c''(x) for c'' s.t. p_c''(x) > p_c'(x).
      2) If {0 or 1} or 2 in S(x) => do NOT recommend
         Else if 3 in S(x) => recommend => total_maxmin += 1
         Else => recommend => total_maxmin += 2
         Realized utility is set accordingly.

    We now also:
      - Check coverage: (true_label in S(x))
      - Track a histogram of realized utilities
      - Return coverage, avg_utility, avg_maxmin, recommend% by rating, plus utility histogram
    """
    model.eval()
    model.to(device)
    
    total_utility = 0.0
    total_maxmin = 0.0
    total_samples = 0
    
    # Coverage count
    coverage_count = 0
    
    # For realized utilities, create a histogram. We don't know the possible range,
    # but let's store them in a Counter, which can handle any integer or float.
    from collections import defaultdict
    utility_histogram = defaultdict(int)
    utility_values = []

    # rating_counts[r], recommend_counts[r] for r in [1..5]
    rating_counts = {r: 0 for r in range(1, 6)}
    recommend_counts = {r: 0 for r in range(1, 6)}
    
    with torch.no_grad():
        for batch in test_loader:
            (user_ids, item_ids, side_info), y_class = batch
            user_ids = user_ids.to(device)
            item_ids = item_ids.to(device)
            side_info = side_info.to(device)
            y_class   = y_class.to(device)  # in [0..4]
            
            # 1) Compute probabilities
            logits = model(user_ids, item_ids, side_info)
            probs  = torch.softmax(logits, dim=1)  # (batch_size, 5)
            
            batch_size = y_class.shape[0]
            
            for i in range(batch_size):
                c = int(y_class[i].item())  # true class in [0..4]
                r = c + 1                   # true rating in [1..5]
                rating_counts[r] += 1
                total_samples += 1
                
                # 2) Build S(x)
                p_vec = probs[i]  # shape (5,)
                S_indices = []
                for cprime in range(5):
                    p_cprime = p_vec[cprime].item()
                    score_cp = 0.0
                    for c2 in range(5):
                        if c2 != cprime:
                            p_c2 = p_vec[c2].item()
                            if p_c2 > p_cprime:
                                score_cp += p_c2
                    if score_cp <= T:
                        S_indices.append(cprime)
                
                # 3) Coverage check
                if c in S_indices:
                    coverage_count += 1
                
                # 4) Decide recommended / not recommended 
                #    and compute realized utility + maxmin 
                if (0 in S_indices) or (1 in S_indices) or (2 in S_indices):
                    # do NOT recommend
                    utility = u(0, c)
                    total_maxmin += 0
                elif 3 in S_indices:
                    # recommend => utility = (c+1) - 3 = c - 2
                    utility = u(1, c)
                    total_maxmin += 1
                    recommend_counts[r] += 1
                else:
                    utility = u(1, c)
                    total_maxmin += 2
                    recommend_counts[r] += 1
                
                total_utility += utility
                utility_values.append(utility)
                utility_histogram[utility] += 1

    # 5) Summaries
    coverage = coverage_count / total_samples if total_samples > 0 else 0.0
    avg_utility = total_utility / total_samples if total_samples > 0 else 0.0
    avg_maxmin = total_maxmin / total_samples if total_samples > 0 else 0.0
    
    recommend_percents = {}
    for r in range(1, 6):
        if rating_counts[r] > 0:
            recommend_percents[r] = 100.0 * recommend_counts[r] / rating_counts[r]
        else:
            recommend_percents[r] = 0.0
    
    # Convert histogram to PDF
    total_hist_count = sum(utility_histogram.values())
    utility_pdf = {}
    for val, cnt in utility_histogram.items():
        if total_hist_count > 0:
            utility_pdf[val] = cnt / total_hist_count
        else:
            utility_pdf[val] = 0.0
    
    # Print summary
    print("=== Conformal Policy (newscore) ===")
    print(f"Threshold T = {T:.4f}")
    print(f"Coverage = {coverage:.3f}")
    print(f"Average Utility = {avg_utility:.4f}")
    print(f"Average Max-Min Value = {avg_maxmin:.4f}\n")
    
    print("Recommend % by TRUE rating:")
    for r in [1, 2, 3, 4, 5]:
        print(f"  Rating={r}: recommended {recommend_percents[r]:.2f}%")
    
    print("\nUtility Histogram (Empirical Distribution):")
    for val in sorted(utility_pdf.keys()):
        print(f"  Utility {val}: {utility_pdf[val]:.4f}")
    
    # Return dictionary
    results_dict = {
        "coverage": coverage,
        "avg_utility": avg_utility,
        "avg_maxmin_value": avg_maxmin,
        "recommend_percents": recommend_percents,
        "utility_histogram": dict(utility_histogram),
        "utility_pdf": utility_pdf
    }
    return results_dict
