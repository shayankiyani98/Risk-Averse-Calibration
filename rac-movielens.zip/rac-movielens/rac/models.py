# Models (embed/MLP classifier)

import os
import requests
import zipfile
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import random
from collections import defaultdict, Counter
    from collections import defaultdict
from collections import Counter
import math
from tqdm import tqdm
    from tqdm import tqdm  # If you prefer to track progress
import matplotlib.pyplot as plt


# --- Auto-extracted block ---
# From cell 1

###############################################################################
# Download & load raw data
###############################################################################

def download_movielens_100k(dest_path='ml-100k.zip'):
    url = "https://files.grouplens.org/datasets/movielens/ml-100k.zip"
    if not os.path.exists(dest_path):
        print("Downloading MovieLens 100k dataset...")
        r = requests.get(url, stream=True)
        with open(dest_path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024):
                if chunk:
                    f.write(chunk)
        print("Download completed.")
    else:
        print("MovieLens 100k zip already exists. Skipping download.")

def extract_movielens_100k(zip_path='ml-100k.zip', extract_to='.'):
    ml_folder = os.path.join(extract_to, 'ml-100k')
    if not os.path.exists(ml_folder):
        print("Extracting ml-100k.zip...")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)
        print("Extraction completed.")
    else:
        print("ml-100k folder already exists. Skipping extraction.")

def load_ratings(path='ml-100k/u.data'):
    df = pd.read_csv(
        path,
        sep='\t',
        names=["user_id", "item_id", "rating", "timestamp"],
        engine='python'
    )
    return df

def load_users(path='ml-100k/u.user'):
    user_cols = ["user_id", "age", "gender", "occupation", "zip_code"]
    df_users = pd.read_csv(
        path,
        sep='|',
        names=user_cols,
        engine='python'
    )
    return df_users

def load_items(path='ml-100k/u.item'):
    item_cols = [
        "item_id",
        "movie_title",
        "release_date",
        "video_release_date",
        "imdb_url",
        "unknown",
        "Action",
        "Adventure",
        "Animation",
        "Children's",
        "Comedy",
        "Crime",
        "Documentary",
        "Drama",
        "Fantasy",
        "Film-Noir",
        "Horror",
        "Musical",
        "Mystery",
        "Romance",
        "Sci-Fi",
        "Thriller",
        "War",
        "Western"
    ]
    df_items = pd.read_csv(
        path,
        sep='|',
        names=item_cols,
        encoding='latin-1',
        engine='python'
    )
    return df_items

def split_data(df, train_frac=0.8, calib_frac=0.1, test_frac=0.1, seed=42):
    df_shuffled = df.sample(frac=1, random_state=seed).reset_index(drop=True)
    n = len(df_shuffled)
    train_end = int(train_frac * n)
    calib_end = int((train_frac + calib_frac) * n)
    
    train_df = df_shuffled.iloc[:train_end]
    calib_df = df_shuffled.iloc[train_end:calib_end]
    test_df = df_shuffled.iloc[calib_end:]
    return train_df, calib_df, test_df

###############################################################################
# Preprocessing (including user/item ID reindexing & classification target)
###############################################################################

def preprocess_data_classification(merged_df):
    """
    1. Convert rating in [1..5] => class index [0..4].
    2. Re-index user_id and item_id => [0..num_users-1], [0..num_items-1].
    3. Encode gender => {M:0, F:1}, encode occupation & zip_code.
    4. Extract release_year from release_date.
    5. Return a DataFrame with numeric columns and these new IDs.
    """
    df = merged_df.copy()
    
    # 1) rating => [0..4]
    df['rating_class'] = df['rating'] - 1  # rating 1 => class 0, rating 5 => class 4
    
    # 2) re-index user_id
    unique_users = df['user_id'].unique()
    user2idx = {u: i for i, u in enumerate(unique_users)}
    df['user_id_idx'] = df['user_id'].map(user2idx)
    
    # re-index item_id
    unique_items = df['item_id'].unique()
    item2idx = {i: j for j, i in enumerate(unique_items)}
    df['item_id_idx'] = df['item_id'].map(item2idx)
    
    # 3) encode gender => {M:0, F:1}
    df['gender'] = df['gender'].map({'M': 0, 'F': 1}).fillna(0).astype(int)
    
    # encode occupation
    occ_unique = df['occupation'].unique().tolist()
    occ_to_idx = {o: i for i, o in enumerate(occ_unique)}
    df['occupation'] = df['occupation'].map(occ_to_idx).fillna(0).astype(int)
    
    # encode zip_code similarly
    zip_unique = df['zip_code'].unique().tolist()
    zip_to_idx = {z: i for i, z in enumerate(zip_unique)}
    df['zip_code'] = df['zip_code'].map(zip_to_idx).fillna(0).astype(int)
    
    # 4) parse release_year
    def extract_year(date_str):
        if pd.isna(date_str):
            return 0
        parts = date_str.split('-')
        if len(parts) == 3:
            try:
                return int(parts[2])  # e.g. "01-Jan-1994" => 1994
            except:
                return 0
        else:
            return 0
    df['release_year'] = df['release_date'].apply(extract_year)
    
    # drop unused columns
    df.drop(columns=['movie_title', 'release_date', 'video_release_date',
                     'imdb_url'], inplace=True)
    
    return df, user2idx, item2idx

###############################################################################
# PyTorch Dataset for classification
###############################################################################

class MovieLensClassifDataset(Dataset):
    def __init__(self, df):
        super().__init__()
        
        # We'll store user_id_idx, item_id_idx as separate columns for embeddings
        self.user_ids = torch.tensor(df['user_id_idx'].values, dtype=torch.long)
        self.item_ids = torch.tensor(df['item_id_idx'].values, dtype=torch.long)
        
        # rating_class is [0..4]
        self.y = torch.tensor(df['rating_class'].values, dtype=torch.long)
        
        # Prepare side features: age, gender, occupation, zip_code, timestamp, release_year, plus genre flags, etc.
        # We'll decide which columns to treat as side features:
        side_cols = [
            'age', 'gender', 'occupation', 'zip_code', 'timestamp', 'release_year',
            'unknown', 'Action', 'Adventure', 'Animation', "Children's", 'Comedy',
            'Crime', 'Documentary', 'Drama', 'Fantasy', 'Film-Noir', 'Horror',
            'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Thriller', 'War', 'Western'
        ]
        
        # Make sure those columns exist in df
        for col in side_cols:
            if col not in df.columns:
                df[col] = 0  # or handle differently if missing
        
        self.side_info = torch.tensor(df[side_cols].values, dtype=torch.float32)
        self.side_cols = side_cols
    
    def __len__(self):
        return len(self.user_ids)
    
    def __getitem__(self, idx):
        return (self.user_ids[idx], 
                self.item_ids[idx], 
                self.side_info[idx]), self.y[idx]

###############################################################################
# Model: Embedding for user/item + MLP on side info => combine => final 5 logits
###############################################################################

class DeepRecommenderClassifier(nn.Module):
    def __init__(self, 
                 num_users, 
                 num_items, 
                 user_emb_dim=20, 
                 item_emb_dim=20, 
                 side_in_dim=26,  # depends on how many side columns
                 side_hidden=32, 
                 final_hidden=32, 
                 num_classes=5, 
                 dropout_rate=0.3):
        """
        num_users, num_items: for embeddings
        user_emb_dim, item_emb_dim: embedding sizes
        side_in_dim: dimension of side_info
        side_hidden: hidden dim for side MLP
        final_hidden: hidden dim after combining
        num_classes: we have 5 rating classes (0..4)
        dropout_rate: dropout probability
        """
        super().__init__()
        
        # Embeddings
        self.user_emb = nn.Embedding(num_users, user_emb_dim)
        self.item_emb = nn.Embedding(num_items, item_emb_dim)
        
        # MLP for side info with BatchNorm and Dropout
        self.side_mlp = nn.Sequential(
            nn.Linear(side_in_dim, side_hidden),
            nn.BatchNorm1d(side_hidden),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(side_hidden, side_hidden),
            nn.BatchNorm1d(side_hidden),
            nn.ReLU(),
            nn.Dropout(dropout_rate)
        )
        
        # Final combination
        comb_in_dim = user_emb_dim + item_emb_dim + side_hidden
        
        self.final_mlp = nn.Sequential(
            nn.Linear(comb_in_dim, final_hidden),
            nn.BatchNorm1d(final_hidden),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(final_hidden, num_classes)
        )
        
    def forward(self, user_ids, item_ids, side_info):
        # Look up embeddings
        ue = self.user_emb(user_ids)   # (batch, user_emb_dim)
        ie = self.item_emb(item_ids)   # (batch, item_emb_dim)
        
        # MLP on side info
        se = self.side_mlp(side_info)  # (batch, side_hidden)
        
        # Combine
        x = torch.cat([ue, ie, se], dim=1)  # (batch, user_dim + item_dim + side_hidden)
        logits = self.final_mlp(x)          # (batch, 5)
        return logits

###############################################################################
# Training + accuracy
###############################################################################

def train_one_epoch_classif(model, loader, optimizer, device='cpu'):
    model.train()
    criterion = nn.CrossEntropyLoss()
    total_loss = 0.0
    total_samples = 0
    
    for (user_ids, item_ids, side_info), y_class in loader:
        user_ids = user_ids.to(device)
        item_ids = item_ids.to(device)
        side_info = side_info.to(device)
        y_class = y_class.to(device)
        
        optimizer.zero_grad()
        logits = model(user_ids, item_ids, side_info)
        loss = criterion(logits, y_class)
        loss.backward()
        optimizer.step()
        
        batch_size = y_class.size(0)
        total_loss += loss.item() * batch_size
        total_samples += batch_size
    
    avg_loss = total_loss / total_samples
    return avg_loss

def evaluate_classif(model, loader, device='cpu'):
    """
    Returns average cross-entropy and accuracy (exact match).
    """
    model.eval()
    criterion = nn.CrossEntropyLoss(reduction='sum')  # sum to do total
    total_loss = 0.0
    total_correct = 0
    total_samples = 0
    
    with torch.no_grad():
        for (user_ids, item_ids, side_info), y_class in loader:
            user_ids = user_ids.to(device)
            item_ids = item_ids.to(device)
            side_info = side_info.to(device)
            y_class = y_class.to(device)
            
            logits = model(user_ids, item_ids, side_info)
            loss = criterion(logits, y_class)
            
            # Accuracy
            preds = torch.argmax(logits, dim=1)
            total_correct += (preds == y_class).sum().item()
            
            total_samples += y_class.size(0)
            total_loss += loss.item()
    
    avg_loss = total_loss / total_samples
    accuracy = 100.0 * total_correct / total_samples
    return avg_loss, accuracy
