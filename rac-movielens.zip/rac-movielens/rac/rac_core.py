# RAC core primitives

import os
import requests
import zipfile
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import random
from collections import defaultdict, Counter
    from collections import defaultdict
from collections import Counter
import math
from tqdm import tqdm
    from tqdm import tqdm  # If you prefer to track progress
import matplotlib.pyplot as plt


# --- Auto-extracted block ---
# From cell 10
import math
import numpy as np

def hbtheta_and_arg(t, actions, f_x, utility_fn):
    """
    Compute (hbtheta_value, best_action) for a single x,t.

    :param t: float in [0,1], feasibility threshold
    :param actions: iterable of possible actions (e.g. [0,1,2,3])
    :param f_x: 1D array-like of probabilities f_x[y], summing to ~1, for y in label space {0..len(f_x)-1}
    :param utility_fn: a function utility_fn(a,y) -> real number
    :return: (best_u, best_a)
      best_u = hbtheta(x,t)
      best_a = argmax action that achieves best_u
    """

    # Convert f_x to a numpy array for vector operations (if not already)
    f_x = np.array(f_x, dtype=float)
    
    # We'll assume the label space is y in [0..len(f_x)-1].
    Y = np.arange(len(f_x))

    best_u = -math.inf
    best_a = None

    for a in actions:
        # 1) Compute utility for each label y
        #    shape: (len(Y),)
        utilities_for_a = np.array([utility_fn(a, y) for y in Y], dtype=float)

        # 2) Get unique utility values in descending order
        #    e.g. [9, 8, 4, 0, ...]
        unique_util_vals = np.unique(utilities_for_a)
        unique_util_vals = np.sort(unique_util_vals)[::-1]  # descending

        # 3) For each candidate utility value, check if sum_{y : utility>=candidate} f_x[y] >= t
        candidate_u = -math.inf
        for u_candidate in unique_util_vals:
            # Create a boolean mask for labels where utility >= u_candidate
            mask = (utilities_for_a >= u_candidate)
            sum_prob = np.sum(f_x[mask])

            if sum_prob >= t:
                candidate_u = u_candidate
                break  # no need to check smaller utilities
        
        # 4) Compare across actions
        if candidate_u > best_u:
            best_u = candidate_u
            best_a = a

    return best_u, best_a

# --- Auto-extracted block ---
# From cell 11
import numpy as np
import math

def compute_g_hat(x_probs, beta, actions, utility_fn):
    """
    Compute g_hat(x, beta) = argmax_{s in [0,1]} [ beta*s + h_btheta(x, s) ]
    using only the *relevant* thresholds derived from T(a, u).

    :param x_probs: 1D array-like of probabilities f_x[y], sums to 1
    :param beta: float parameter in [0, 2] (or any real range)
    :param actions: list/iterable of possible actions
    :param utility_fn: function utility_fn(a,y) -> float
    :return: s_star in [0,1] that maximizes beta*s + h_btheta(x, s)
    
    Explanation:
      - We do NOT search a full grid of 101 points.
      - Instead, for each action a, we gather unique utility values u in descending order,
        compute T(a,u) = sum_{y : utility(a,y) >= u} x_probs[y].
      - h_btheta(x, s) changes only at these T(a,u) thresholds (plus possibly 0 or 1).
      - We then evaluate phi(s) = beta*s + h_btheta(x, s) only at these discrete s-values.
      - The s that yields the highest phi(s) is returned.
    """
    x_probs = np.asarray(x_probs, dtype=float)
    num_labels = len(x_probs)
    
    # 1) For each action 'a', gather unique utility values + compute T(a,u).
    #    We'll store them in descending order of u so we can quickly parse them.
    #    T(a,u) = sum_{y : utility_fn(a,y) >= u} x_probs[y].
    action_thresholds = {}  # action -> list of (u, T(a,u)) in descending order of u
    all_s_candidates = set([0.0, 1.0])  # we'll include 0 and 1 from the start
    
    for a in actions:
        # Compute utility for each label y
        utilities_for_a = np.array([utility_fn(a, y) for y in range(num_labels)], dtype=float)
        
        # Gather unique utilities in descending order
        unique_utils = np.unique(utilities_for_a)
        unique_utils = np.sort(unique_utils)[::-1]  # descending
        
        # For each u_candidate, compute T(a,u_candidate)
        pairs = []
        for u_candidate in unique_utils:
            mask = (utilities_for_a >= u_candidate)
            t_val = x_probs[mask].sum()
            pairs.append((u_candidate, t_val))
            # This t_val is a potential candidate s
            all_s_candidates.add(float(t_val))  # add to global set of s-candidates
        
        action_thresholds[a] = pairs  # list of (u, T(a,u)) in descending order of u
    
    # 2) Now we have a set of possible s in [0,1], including T(a,u) for all a,u plus {0,1}.
    #    We'll evaluate phi(s) = beta*s + h_btheta(x, s) at each candidate.
    #    h_btheta(x, s) = max_{a} [ largest u in pairs for which T(a,u) >= s ]
    
    s_star = 0.0
    best_score = -math.inf
    
    # We'll convert to a sorted list (ascending or random). Ascending is typical:
    s_candidates = sorted(all_s_candidates)
    
    for s in s_candidates:
        # Compute h_btheta(x, s)
        # For each action a, find the largest u s.t. T(a,u) >= s
        best_u_for_s = -math.inf
        
        for a, pairs in action_thresholds.items():
            # 'pairs' is in descending order of u, so T(a,u) is presumably non-increasing as we go
            # from bigger to smaller u. We'll do a quick linear scan:
            feasible_u = -math.inf
            for (u_candidate, t_val) in pairs:
                if t_val >= s:
                    feasible_u = u_candidate
                    break
            if feasible_u > best_u_for_s:
                best_u_for_s = feasible_u
        
        # Now we have h_btheta(x, s) = best_u_for_s
        # phi(s) = beta*s + best_u_for_s
        phi_s = beta*s + best_u_for_s
        
        if phi_s > best_score:
            best_score = phi_s
            s_star = s
    
    return s_star

# --- Auto-extracted block ---
# From cell 14
from tqdm import tqdm

def get_conformal_set(x_probs, s_value, actions, utility_fn):
    """
    Vectorized approach:
      1) (best_u, best_a) = hbtheta_and_arg(s_value, actions, x_probs, utility_fn)
      2) u_vec[y] = utility_fn(best_a, y)
      3) y in c_star if sum_{y': u_vec[y'] >= u_vec[y]} x_probs[y'] >= s_value
    """
    num_labels = len(x_probs)
    best_u, best_a = hbtheta_and_arg(s_value, actions, x_probs, utility_fn)

    # Vector of shape (num_labels,) for this chosen action
    u_vec = np.array([utility_fn(best_a, y) for y in range(num_labels)], dtype=float)

    c_star = set()

    # We can do an O(num_labels^2) approach with vector masks:
    for y in range(num_labels):
        val_y = u_vec[y]
        mask = (u_vec > val_y)   # vector mask
        sum_prob = x_probs[mask].sum()
        if sum_prob <= s_value:
            c_star.add(y)

    return c_star

def get_conformal_set(x_probs, s_value, actions, utility_fn):
    """
    Vectorized approach:
      1) (best_u, best_a) = hbtheta_and_arg(s_value, actions, x_probs, utility_fn)
      2) u_vec[y] = utility_fn(best_a, y)
      3) y in c_star if sum_{y': u_vec[y'] >= u_vec[y]} x_probs[y'] >= s_value
    """
    num_labels = len(x_probs)
    best_u, best_a = hbtheta_and_arg(s_value, actions, x_probs, utility_fn)

    # Vector of shape (num_labels,) for this chosen action
    u_vec = np.array([utility_fn(best_a, y) for y in range(num_labels)], dtype=float)

    c_star = set()

    # We can do an O(num_labels^2) approach with vector masks:
    for y in range(num_labels):
        val_y = u_vec[y]
        mask = (u_vec > val_y)   # vector mask
        sum_prob = x_probs[mask].sum()
        if sum_prob <= s_value:
            c_star.add(y)

    return c_star


def coverage_for_beta(calib_probs, calib_labels, beta, actions, utility_fn):
    """
    :param calib_probs: list (or array) of length n,
        each element is x_probs[i], i.e. array of shape (num_labels,).
    :param calib_labels: list/array of length n with the true label index for each sample
    :param beta: float
    :param actions: list of possible actions
    :param utility_fn: ...
    :return: coverage in [0,1]
    """
    n = len(calib_probs)
    hits = 0
    for i in range(n):
        x_probs_i = calib_probs[i]
        y_i       = calib_labels[i]
        
        # compute s_i = g_hat(x, beta)
        s_i = compute_g_hat(x_probs_i, beta, actions, utility_fn)
        # get the set
        c_star_i = get_conformal_set(x_probs_i, s_i, actions, utility_fn)
        
        # check coverage
        if y_i in c_star_i:
            hits += 1
    return hits / n


def find_threshold_q(calib_probs, calib_labels, alpha, actions, utility_fn, beta_step=0.01, max_beta=2.0):
    """
    Sweep beta from 0..max_beta with step size = beta_step.
    For each beta, compute coverage. 
    Return the FIRST beta where coverage >= 1 - alpha.

    :param calib_probs: list/array of shape (n,), each is an array (num_labels,) for x_probs
    :param calib_labels: list/array of shape (n,) with the true label index
    :param alpha: in [0,1]
    :param actions: ...
    :param utility_fn: ...
    :param beta_step: step size for the grid
    :param max_beta: max for the grid
    :return: q (float) or None if not found
    """
    beta_val_now = 1
    beta_val_past = 0

    cov = coverage_for_beta(calib_probs, calib_labels, beta_val_now, actions, utility_fn)
#     if cov >= (1.0 - alpha):
#         overcoverage = True
#         beta_val = beta_val/2
#     else:
#         overcoverage = False
#         beta_val = beta_val*2

    while cov < 1 - alpha:
        beta_val_past = beta_val_now
        beta_val_now = beta_val_now *2
        cov = coverage_for_beta(calib_probs, calib_labels, beta_val_now, actions, utility_fn)
#         print(beta_val_now, cov)
        
    for T in range(20):
        beta_val_mean = (beta_val_past + beta_val_now)/2
        cov = coverage_for_beta(calib_probs, calib_labels, beta_val_mean, actions, utility_fn)
#         print(beta_val_mean, cov)
        if cov >= (1.0 - alpha):
            beta_val_now = beta_val_mean
        else:
            beta_val_past = beta_val_mean
    
#     while beta_val <= max_beta + 1e-9:
#         print(beta_val)
#         cov = coverage_for_beta(calib_probs, calib_labels, beta_val, actions, utility_fn)
#         # Check coverage
#         if cov >= (1.0 - alpha):
#             return beta_val
#         beta_val += beta_step
    # If we never reached coverage
    return (beta_val_past + beta_val_now)/2
