# Misc utilities

import os
import requests
import zipfile
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import random
from collections import defaultdict, Counter
    from collections import defaultdict
from collections import Counter
import math
from tqdm import tqdm
    from tqdm import tqdm  # If you prefer to track progress
import matplotlib.pyplot as plt


# --- Auto-extracted block ---
# Unrouted helpers from notebook cells

# --- Cell 0 ---
import os
import requests
import zipfile
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import random



random.seed(42)
np.random.seed(42)
torch.manual_seed(42)
if torch.cuda.is_available():
    torch.cuda.manual_seed(42)
    torch.cuda.manual_seed_all(42)


# --- Cell 2 ---
device = 'cuda:3' if torch.cuda.is_available() else 'cpu'
print("Using device:", device)

# 1. Download & extract
download_movielens_100k("ml-100k.zip")
extract_movielens_100k("ml-100k.zip", ".")

# 2. Load data
ratings_df = load_ratings("ml-100k/u.data")
users_df   = load_users("ml-100k/u.user")
items_df   = load_items("ml-100k/u.item")

# 3. Merge
merged_df = pd.merge(ratings_df, users_df, on="user_id", how="left")
merged_df = pd.merge(merged_df, items_df, on="item_id", how="left")

# 4. Preprocess for classification
df_classif, user2idx, item2idx = preprocess_data_classification(merged_df)

# 5. Split
train_df, calib_df, test_df = split_data(df_classif, 0.8, 0.1, 0.1, seed=42)
print(f"Train: {train_df.shape}, Calib: {calib_df.shape}, Test: {test_df.shape}")

# 6. Datasets & Loaders
train_data = MovieLensClassifDataset(train_df)
calib_data = MovieLensClassifDataset(calib_df)
test_data  = MovieLensClassifDataset(test_df)

train_loader = DataLoader(train_data, batch_size=256, shuffle=True)
calib_loader = DataLoader(calib_data, batch_size=256, shuffle=False)
test_loader  = DataLoader(test_data, batch_size=256, shuffle=False)

# 7. Model
num_users = len(user2idx)
num_items = len(item2idx)
# side_in_dim = number of features in side_info (determined by dataset). 
# Let's see:
side_in_dim = train_data.side_info.shape[1]
print("Side info dimension:", side_in_dim)

model = DeepRecommenderClassifier(
    num_users=num_users, 
    num_items=num_items,
    user_emb_dim=32, 
    item_emb_dim=32,
    side_in_dim=side_in_dim,
    side_hidden=64,
    final_hidden=64,
    num_classes=5
).to(device)

optimizer = optim.Adam(model.parameters(), lr=1e-3)

# 8. Training loop
epochs = 20
for epoch in range(1, epochs+1):
    train_loss = train_one_epoch_classif(model, train_loader, optimizer, device)
    val_loss, val_acc = evaluate_classif(model, calib_loader, device)
    print(f"Epoch {epoch}/{epochs}: Train Loss={train_loss:.4f}, "
          f"Val Loss={val_loss:.4f}, Val Acc={val_acc:.2f}%")

# 9. Final test evaluation
test_loss, test_acc = evaluate_classif(model, test_loader, device)
print(f"\nFinal Test Loss={test_loss:.4f}, Test Accuracy={test_acc:.2f}%")


# --- Cell 4 ---
avg_utility, recommend_stats, utility_pdf, _ = evaluate_baseline_best_response(model, test_loader, 0.1, device=device)
print(utility_pdf)

# --- Cell 6 ---
results

# --- Cell 8 ---
def example_utility_fn(a, y):
    # a=0 => "not recommend", a=1 => "recommend"
    if a == 0:
        return 0.0
    else:
        # a=1 => let's define u = (y-2)
        return float(y - 2)
    


alpha = 0.2
T_new = compute_conformal_threshold_newscore(model, calib_loader, alpha=alpha, device=device)

# 2) Evaluate on test with the new policy
results = evaluate_conformal_policy_newscore(
    model, 
    test_loader, 
    T_new,
    example_utility_fn,
    device=device
)

# --- Cell 9 ---
print(results)

# --- Cell 12 ---
# 1) Define a utility function
def example_utility_fn(a, y):
    # a=0 => "not recommend", a=1 => "recommend"
    if a == 0:
        return 0.0
    else:
        # a=1 => let's define u = (y-2)
        return float(y - 2)

# 2) Example distribution over y in [0..4]
f_x = [0.1, 0.1, 0.4, 0.2, 0.2]  # sums to 1.0

# 3) Our set of actions
actions = [0,1]  # or ["not_rec","rec"] if you prefer

# 4) Example t
t = 0.1

# 5) Call the function
best_u, best_a = hbtheta_and_arg(t, actions, f_x, example_utility_fn)
print(f"hbtheta(x={f_x}, t={t}) = {best_u}")
print(f"arg_hbtheta(x={f_x}, t={t}) = {best_a}")


# --- Cell 13 ---
# Reuse the toy example from before:
def example_utility_fn(a, y):
    # a=0 => utility=0 always, a=1 => utility=(y-2).
    if a == 0:
        return 0.0
    else:
        return float(y - 2)

f_x = [0.1, 0.1, 0.4, 0.2, 0.2]  # sums to 1
actions = [0,1]
beta = 5.6

# We assume 'hbtheta_and_arg' is defined from previous steps
g_star = compute_g_hat(f_x, beta, actions, example_utility_fn)
print(f"g_star for beta={beta} is {g_star:.3f}")


# --- Cell 18 ---
# Example usage (adjust variable names as needed):

device = 'cuda:3' if torch.cuda.is_available() else 'cpu'
alpha  = 0.05    # or whichever coverage you want

# 1) Get calibration data
calib_probs, calib_labels = get_probs_and_labels(model, calib_loader, device=device)

# 2) Get test data
test_probs, test_labels = get_probs_and_labels(model, test_loader, device=device)

# 3) Define your action set and utility function
actions = [0, 1]   # e.g. 0 => "not recommend", 1 => "recommend"
def utility_fn(a, y):
    """
    Example: if a=0 => 0, if a=1 => (y+1)-3 = y-2
    (assuming y in [0..4], i.e. rating in [1..5] is y+1).
    Adjust to your domain's utility.
    """
    if a == 0:
        return 0.0
    else:
        # rating = y+1, so utility = (rating) - 3 = (y+1) - 3 = y - 2
        return float(y - 2)

# 4) Run the conformal pipeline
q, results = run_conformal_evaluation(
    calib_probs=calib_probs,
    calib_labels=calib_labels,
    test_probs=test_probs,
    test_labels=test_labels,
    alpha=alpha,
    actions=actions,
    utility_fn=utility_fn,
    beta_step=0.01,
    max_beta=2.0
)

print("\n=== Final Results ===")
print(f"Chosen q = {q}")
print("Metrics on test set:", results)


# q, test_stats = run_conformal_evaluation(
#     calib_probs, calib_labels,
#     test_probs,  test_labels,
#     alpha,
#     actions,
#     utility_fn,
#     beta_step=0.01,   # or 0.005
#     max_beta=2.0
# )

# # If q is not None, you'll see coverage & utility on the test set printed out.
# test_stats is a dict with keys: "test_coverage", "avg_utility", "rec_per_label".


# --- Cell 20 ---
actions = [0,1]
def utility_fn(a, y):
    """
    Example: if a=0 => 0, if a=1 => (y+1)-3 = y-2
    (assuming y in [0..4], i.e. rating in [1..5] is y+1).
    Adjust to your domain's utility.
    """
    if a == 0:
        return 0.0
    else:
        # rating = y+1, so utility = (rating) - 3 = (y+1) - 3 = y - 2
        return float(y - 2)


alpha_list = [0.005, 0.01, 0.02, 0.05, 0.1, 0.15, 0.2, 0.25]

avg_b =[]
avg_ours =[]
avg_s1 =[]
avg_s2 =[]
avg_s3 =[] 

q_b =[]
q_ours =[]
q_s1 =[]
q_s2 =[]
q_s3 =[] 

# avg_b =[]
max_ours =[]
max_s1 =[]
max_s2 =[]
max_s3 =[] 

for alpha in tqdm(alpha_list):
    
    q, results = run_conformal_evaluation(
    calib_probs=calib_probs,
    calib_labels=calib_labels,
    test_probs=test_probs,
    test_labels=test_labels,
    alpha=alpha,
    actions=actions,
    utility_fn=utility_fn,
    beta_step=0.01,
    max_beta=2.0
    )
    
    avg_ours.append(results['avg_utility'])
    q_ours.append(1 - results['coverage'])
    max_ours.append(results['avg_maxmin_value'])
    
    
    T = compute_conformal_threshold(model, calib_loader, alpha=alpha, device=device)
    results= evaluate_conformal_policy(model, test_loader, T, utility_fn, 0.1, device=device)

    avg_s1.append(results['avg_utility'])
    q_s1.append(1 - results['coverage'])
    max_s1.append(results['avg_maxmin_value'])
    
    
    T_new = compute_conformal_threshold_newscore(model, calib_loader, alpha=alpha, device=device)

    # 2) Evaluate on test with the new policy
    results = evaluate_conformal_policy_newscore(
        model, 
        test_loader, 
        T_new,
        utility_fn,
        device=device
    )
    
    avg_s2.append(results['avg_utility'])
    q_s2.append(1 - results['coverage'])
    max_s2.append(results['avg_maxmin_value'])

    

# --- Cell 21 ---
avg_utility, recommend_stats, utility_pdf, _ = evaluate_baseline_best_response(model, test_loader, 0.1, device=device)
print(utility_pdf)

# --- Cell 22 ---
avg_b =[0.6007, 0.6007, 0.6007, 0.6007, 0.6007, 0.6007, 0.6007, 0.6007] 
q_b =[0, 0, 0, 0, 0, 0, 0]

# --- Cell 23 ---
# Values for each plot (replace with your actual data)

avg_s3 = [0.0414, 0.0762, 0.1511, 0.2489, 0.3706, 0.4532, 0.5003, 0.5309]

q_s3 = [(q_s2[a] + q_s1[a])/2 for a in range(len(q_s1))]

max_s3 = [0.0258, 0.0635, 0.1321, 0.2494, 0.404, 0.5587, 0.7035, 0.854]


# --- Cell 24 ---
print(max_ours)
print(max_s2)
print(max_s1)

# --- Cell 25 ---
import matplotlib.pyplot as plt

import matplotlib.pyplot as plt
import numpy as np

# Example values (you can replace these with your actual data)

alpha_list = [0.005, 0.01, 0.02, 0.05, 0.1, 0.15, 0.2, 0.25]
# Define consistent colors
colors = {
    'ours': 'black',
    'b': 'blue',
    's1': 'orange',
    's2': 'green',
    's3': 'red'
}


# Create the plots
fig, axes = plt.subplots(1, 3, figsize=(15, 5), dpi=300, sharey=False)

# Plot 1: Averages
axes[2].plot(alpha_list, avg_b, label='Best respond', marker='o', color=colors['b'])
axes[2].plot(alpha_list, avg_ours, label='RAC', marker='s', color=colors['ours'])
axes[2].plot(alpha_list, avg_s1, label='score-1', marker='^', color=colors['s1'])
axes[2].plot(alpha_list, avg_s2, label='score-2', marker='d', color=colors['s2'])
axes[2].plot(alpha_list, avg_s3, label='score-3', marker='x', color=colors['s3'])
axes[2].set_xlabel('Alpha (nominal miscoverage)')
axes[2].set_ylabel('Average realized utility')
axes[2].legend()
# axes[0].set_xticks(alpha_list)  # Set x-axis ticks to alpha_list

# Plot 2: Q-values
axes[1].plot(alpha_list, q_ours, label='RAC', marker='s', color=colors['ours'])
axes[1].plot(alpha_list, q_s1, label='score-1', marker='^', color=colors['s1'])
axes[1].plot(alpha_list, q_s2, label='score-2', marker='d', color=colors['s2'])
axes[1].plot(alpha_list, q_s3, label='score-3', marker='x', color=colors['s3'])

# Add x = y baseline as dotted line
axes[1].plot(alpha_list, alpha_list, label='x = y', linestyle=':', color='gray')

axes[1].set_xlabel('Alpha (nominal miscoverage)')
axes[1].set_ylabel('Realized miscoverage')
# axes[1].set_title('Plot of Q-values')
axes[1].legend()
# axes[1].set_xticks(alpha_list)  # Set x-axis ticks to alpha_list

# Plot 3: Maximums
axes[0].plot(alpha_list, max_ours, label='RAC', marker='s', color=colors['ours'])
axes[0].plot(alpha_list, max_s1, label='score-1', marker='^', color=colors['s1'])
axes[0].plot(alpha_list, max_s2, label='score-2', marker='d', color=colors['s2'])
axes[0].plot(alpha_list, max_s3, label='score-3', marker='x', color=colors['s3'])
axes[0].set_xlabel('Alpha (nominal miscoverage)')
axes[0].set_ylabel('Average realized maxmin value')
axes[0].legend()
# axes[2].set_xticks(alpha_list)  # Set x-axis ticks to alpha_list

# Adjust layout
plt.tight_layout()

# Save the figure
plt.savefig("icml_three_plots.pdf")
plt.show()


# --- Cell 26 ---
import matplotlib.pyplot as plt
import numpy as np

# Data for Utility PDF (Empirical Distribution)
utility_pdf_values = [-2.0, -1.0, 0.0, 1.0, 2.0]
pdf_probabilities = [0.0143, 0.0290, 0.5597, 0.2198, 0.1772]

# Data for Utility Histogram (Empirical PDF)
utility_hist_values = [-2, -1, 0, 1, 2]
hist_probabilities = [0.0248, 0.0678, 0.3902, 0.3163, 0.2009]

# Plot settings
bar_width = 0.4
x_pdf = np.array(utility_pdf_values)
x_hist = np.array(utility_hist_values) + bar_width  # Shift for side-by-side comparison

plt.figure(figsize=(10, 6))

# Plot bars for Utility PDF
plt.bar(x_pdf, pdf_probabilities, width=bar_width, label='Utility PDF (Empirical Distribution)', alpha=0.7)

# Plot bars for Utility Histogram
plt.bar(x_hist, hist_probabilities, width=bar_width, label='Utility Histogram (Empirical PDF)', alpha=0.7)

# Add labels and title
plt.xlabel('Utility', fontsize=12)
plt.ylabel('Probability', fontsize=12)
plt.title('Comparison of Utility PDF and Utility Histogram', fontsize=14)
plt.xticks(ticks=utility_pdf_values, labels=[-2, -1, 0, 1, 2])
plt.legend()
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Show the plot
plt.tight_layout()
plt.show()


# --- Cell 27 ---
import matplotlib.pyplot as plt
import numpy as np

# Data for True Ratings
true_rating_labels = ["True Rating 1 ---> Recommend", "True Rating 2 ---> Recommend"]
true_rating_percent = [38.63, 56.83]
true_rating_fraction1 = [143/642 *100, 290/1193* 100]
true_rating_fraction2 = [58/642* 100, 165/1193* 100]

# Combine all data for plotting
bar_width = 0.2
x = np.arange(len(true_rating_labels))

plt.figure(figsize=(10, 6))

# Plot bars for Percentage
plt.bar(x - bar_width, true_rating_percent, width=bar_width, label='Best respond', color='blue', alpha=0.7)

# Plot bars for Fraction 1
plt.bar(x, true_rating_fraction1, width=bar_width, label='Fraction Recommended (Set 1)', color='green', alpha=0.7)

# Plot bars for Fraction 2
plt.bar(x + bar_width, true_rating_fraction2, width=bar_width, label='Fraction Recommended (Set 2)', color='red', alpha=0.7)

# Add labels and title
plt.xlabel('True Ratings', fontsize=12)
plt.ylabel('Percentage of critical mistakes', fontsize=12)
plt.title('Comparison of True Ratings', fontsize=14)
plt.xticks(ticks=x, labels=true_rating_labels)
plt.legend()
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Show the plot
plt.tight_layout()
plt.show()


# --- Cell 28 ---
import matplotlib.pyplot as plt
import numpy as np

# Example values (you can replace these with your actual data)
alpha_list = [0.005, 0.01, 0.02, 0.05, 0.1, 0.15, 0.2, 0.25]
# Define consistent colors
colors = {
    'ours': 'black',
    'b': 'blue',
    's1': 'orange',
    's2': 'green',
    's3': 'red'
}


# Data for True Ratings
true_rating_labels = ["True Rating 1 -> Recommend", "True Rating 2 -> Recommend"]
true_rating_percent = [38.63, 56.83]
true_rating_fraction1 = [143/642 * 100, 290/1193 * 100]
true_rating_fraction2 = [58/642 * 100, 165/1193 * 100]

# Combine all data for plotting
bar_width = 0.2
x = np.arange(len(true_rating_labels))

# Create a 2x2 grid of plots
fig, axes = plt.subplots(2, 2, figsize=(12, 10), dpi=300)

# Plot 1: Maximums
axes[0, 0].plot(alpha_list, max_ours, label='RAC', marker='s', color=colors['ours'])
axes[0, 0].plot(alpha_list, max_s1, label='score-1', marker='^', color=colors['s1'])
axes[0, 0].plot(alpha_list, max_s2, label='score-2', marker='d', color=colors['s2'])
axes[0, 0].plot(alpha_list, max_s3, label='score-3', marker='x', color=colors['s3'])
axes[0, 0].set_xlabel(r'$\alpha$ (nominal miscoverage)', fontsize = 16)
axes[0, 0].set_ylabel('Average realized maxmin value', fontsize = 16)
axes[0, 0].legend(fontsize = 15)
axes[0, 0].grid(axis='y', linestyle='--', alpha=0.7)
axes[0, 0].set_title('(a)', fontsize=18)

# Plot 2: Q-values
axes[1, 1].plot(alpha_list, q_ours, label='RAC', marker='s', color=colors['ours'])
axes[1, 1].plot(alpha_list, q_s1, label='score-1', marker='^', color=colors['s1'])
axes[1, 1].plot(alpha_list, q_s2, label='score-2', marker='d', color=colors['s2'])
axes[1, 1].plot(alpha_list, q_s3, label='score-3', marker='x', color=colors['s3'])
axes[1, 1].plot(alpha_list, alpha_list, label='x = y', linestyle=':', color='gray')
axes[1, 1].set_xlabel(r'$\alpha$ (nominal miscoverage)', fontsize = 16)
axes[1, 1].set_ylabel('Realized miscoverage', fontsize = 16)
axes[1, 1].legend(fontsize = 15)
axes[1, 1].grid(axis='y', linestyle='--', alpha=0.7)
axes[1, 1].set_title('(d)', fontsize=18)

# Plot 3: Averages
axes[1, 0].plot(alpha_list, avg_b, label='Best response', marker='o', color=colors['b'])
axes[1, 0].plot(alpha_list, avg_ours, label='RAC', marker='s', color=colors['ours'])
axes[1, 0].plot(alpha_list, avg_s1, label='score-1', marker='^', color=colors['s1'])
axes[1, 0].plot(alpha_list, avg_s2, label='score-2', marker='d', color=colors['s2'])
axes[1, 0].plot(alpha_list, avg_s3, label='score-3', marker='x', color=colors['s3'])
axes[1, 0].set_xlabel(r'$\alpha$ (nominal miscoverage)', fontsize = 16)
axes[1, 0].set_ylabel('Average realized utility', fontsize = 16)
axes[1, 0].legend(fontsize = 14)
axes[1, 0].grid(axis='y', linestyle='--', alpha=0.7)
axes[1, 0].set_title('(c)', fontsize=18)

# Plot 4: True Ratings Comparison
axes[0, 1].bar(x - bar_width, true_rating_percent, width=bar_width, label='Best response', color='blue', alpha=0.7)
axes[0, 1].bar(x, true_rating_fraction1, width=bar_width, label=r'RAC ($\alpha$ = 0.1)', color='green', alpha=0.7)
axes[0, 1].bar(x + bar_width, true_rating_fraction2, width=bar_width, label=r'RAC ($\alpha$ = 0.05)', color='red', alpha=0.7)
axes[0, 1].set_title('(b)', fontsize=18)
axes[0, 1].set_ylabel('Percentage of critical mistakes', fontsize=16, fontweight='bold')
axes[0, 1].set_xticks(ticks=x)
axes[0, 1].set_xticklabels(true_rating_labels, fontsize= 12, fontweight='bold', rotation = -6)
axes[0, 1].legend(fontsize = 15)
axes[0, 1].grid(axis='y', linestyle='--', alpha=0.7)

for ax in axes.flat:
    ax.tick_params(axis='both', labelsize=13)  # Increase font size of both x and y ticks
# axes[0, 1].set_xticklabels(true_rating_labels, fontsize= 11, fontweight='bold', rotation = -4)

# Adjust layout
plt.tight_layout()
plt.savefig("icml_2x2_plots_movie.pdf")
plt.show()
