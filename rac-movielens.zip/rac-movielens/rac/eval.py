# Evaluation utilities

import os
import requests
import zipfile
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import random
from collections import defaultdict, Counter
    from collections import defaultdict
from collections import Counter
import math
from tqdm import tqdm
    from tqdm import tqdm  # If you prefer to track progress
import matplotlib.pyplot as plt


# --- Auto-extracted block ---
# From cell 15
import numpy as np
from collections import defaultdict, Counter

def evaluate_test_set(
    test_probs, test_labels, q, actions, utility_fn, alpha
):
    """
    Evaluate the conformal-based policy on the test set, then report
    performance metrics similar to the 'best responder' baseline:
      - Test coverage
      - Average utility
      - True label counts
      - Action counts per true label
      - Utility histogram & PDF
      - alpha-Quantile of realized utilities

    :param test_probs: list/array of shape (num_test_samples,), each an array (num_labels,) of probabilities
    :param test_labels: list/array of shape (num_test_samples,) with the true label indices
    :param q: the threshold from calibration (beta or "q")
    :param actions: list/iterable of possible actions (e.g., [0,1,2,3])
    :param utility_fn: function utility_fn(a, y) -> real
    :param alpha: float in [0,1], for quantile
    :return: A dictionary with coverage, avg_utility, utility_quantile, label_counts,
             action_counts, utility_histogram, and utility_pdf.
    """
    from tqdm import tqdm  # If you prefer to track progress

    total_samples = len(test_probs)
    cover_hits = 0
    total_utility = 0.0

    # We will collect the realized utilities for the alpha-quantile
    realized_utilities = []
    max_min_values = []

    # We'll also track label and action counts
    label_counts = Counter()
    action_counts = defaultdict(Counter)

    # Precompute number of labels (assuming all test_probs have same shape)
    num_labels = len(test_probs[0])

    for i in range(total_samples):
        x_probs = test_probs[i]
        y_true  = test_labels[i]

        label_counts[y_true] += 1

        # 1) s_test = g_hat(x_probs, q)
        s_test = compute_g_hat(x_probs, q, actions, utility_fn)

        # 2) (nu_star, a_star) = hbtheta_and_arg(s_test, actions, x_probs, utility_fn)
        nu_star, a_star = hbtheta_and_arg(s_test, actions, x_probs, utility_fn)
        
        max_min_values.append(nu_star)

        # 3) c_star = get_conformal_set(x_probs, s_test, actions, utility_fn)
        c_star = get_conformal_set(x_probs, s_test, actions, utility_fn)

        # Coverage check
        if y_true in c_star:
            cover_hits += 1

        # Realized utility
        u_val = utility_fn(a_star, y_true)
        total_utility += u_val
        realized_utilities.append(u_val)

        # Action count for each true label
        action_counts[y_true][a_star] += 1

    # Coverage
    test_coverage = cover_hits / total_samples if total_samples > 0 else 0.0
    # Average utility
    avg_utility = total_utility / total_samples if total_samples > 0 else 0.0
    
    avg_max_min_value = np.mean(max_min_values) if len(max_min_values) > 0 else 0.0

    # Utility histogram & PDF
    utility_histogram = Counter(realized_utilities)
    total_hist_count = sum(utility_histogram.values())
    utility_pdf = {u: cnt / total_hist_count for u, cnt in utility_histogram.items()}

    # alpha-quantile of realized utilities
    sorted_utils = sorted(realized_utilities)
    if len(sorted_utils) > 0:
        utility_quantile = float(np.quantile(sorted_utils, alpha))
    else:
        utility_quantile = 0.0

#     Print summary, similar to best_responder
    print("=== Conformal-Based Evaluation ===")
    print(f"Test coverage = {test_coverage:.3f}")
    print(f"Average Utility = {avg_utility:.4f}\n")
    print(f"Average Max–Min Value= {avg_max_min_value:.4f}\n")

    # True label distribution
    print("True Label Counts:")
    for lbl in sorted(label_counts.keys()):
        print(f"  Label {lbl}: {label_counts[lbl]}")
    print("")

    # Action distribution within each true label
    print("Action Counts per True Label:")
    for lbl in sorted(action_counts.keys()):
        acts_str = ", ".join(
            [f"Action {act} -> {action_counts[lbl][act]}" for act in sorted(action_counts[lbl].keys())]
        )
        print(f"  Label {lbl}: {acts_str}")
    print("")

    # Utility Histogram
    print("Utility Histogram (Utility -> Count):")
    for u in sorted(utility_histogram.keys()):
        print(f"  {u}: {utility_histogram[u]}")
    print("")

    # Utility PDF
    print("Utility PDF (Empirical Distribution):")
    for u in sorted(utility_pdf.keys()):
        print(f"  Utility {u}: {utility_pdf[u]:.4f}")
    print("")

    print(f"Alpha-Quantile ({alpha*100:.1f}%): {utility_quantile:.4f}\n")

    # Return the stats in a dict
    return {
        "avg_maxmin_value": avg_max_min_value,
        "coverage": test_coverage,
        "avg_utility": avg_utility,
        "utility_quantile": utility_quantile,
        "label_counts": label_counts,
        "action_counts": action_counts,
        "utility_histogram": utility_histogram,
        "utility_pdf": utility_pdf
    }

# --- Auto-extracted block ---
# From cell 16
def run_conformal_evaluation(
    calib_probs, calib_labels,
    test_probs,  test_labels,
    alpha, actions, utility_fn,
    beta_step=0.01, max_beta=2.0
):
    """
    1) find q
    2) evaluate on test set
    3) return (q, results)
    """
#     print("=== Finding threshold q via calibration ===")
    q = find_threshold_q(calib_probs, calib_labels, alpha, actions, utility_fn,
                         beta_step=beta_step, max_beta=max_beta)
#     if q is None:
#         print("Could not achieve coverage >= 1 - alpha with max_beta =", max_beta)
#         return None, None
#     print(f"Chosen q = {q:.3f}\n")

#     print("=== Evaluating on test set with q ===")
    results = evaluate_test_set(test_probs, test_labels, q, actions, utility_fn, alpha)
    return q, results

# --- Auto-extracted block ---
# From cell 17
import torch

def get_probs_and_labels(model, data_loader, device='cpu'):
    """
    Given a PyTorch classification model, produce:
      - probs_list: list of f_x vectors of shape (5,) for each sample
      - labels_list: list of integer labels in [0..4]
    """
    model.eval()
    model.to(device)

    probs_list = []
    labels_list = []

    with torch.no_grad():
        for batch in data_loader:
            # Adjust to your dataset structure:
            # e.g. batch => ((user_ids, item_ids, side_info), y_class)
            (user_ids, item_ids, side_info), y_class = batch

            user_ids  = user_ids.to(device)
            item_ids  = item_ids.to(device)
            side_info = side_info.to(device)
            y_class   = y_class.to(device)

            logits = model(user_ids, item_ids, side_info)  # shape (batch_size, 5)
            probs = torch.softmax(logits, dim=1)           # shape (batch_size,5)

            # detach => move to CPU => convert to numpy
            probs_np = probs.cpu().numpy()
            labels_np = y_class.cpu().numpy()

            # append each row to the lists
            for i in range(len(labels_np)):
                probs_list.append(probs_np[i])   # shape (5,)
                labels_list.append(int(labels_np[i]))  # label in [0..4]

    return probs_list, labels_list
