
import argparse, os, json, torch
from pathlib import Path
from torch.utils.data import DataLoader

from rac.data import MovieLensClassifDataset
from rac.models import DeepRecommenderClassifier
from rac.eval import get_probs_and_labels, run_conformal_evaluation

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", type=str, default="data/movielens")
    parser.add_argument("--model_ckpt", type=str, default="artifacts/movielens/model.pt")
    parser.add_argument("--alpha", type=float, default=0.05)
    parser.add_argument("--save_dir", type=str, default="artifacts/movielens")
    args = parser.parse_args()

    Path(args.save_dir).mkdir(parents=True, exist_ok=True)

    ds = MovieLensClassifDataset(root=args.data_dir)
    model = DeepRecommenderClassifier(ds.num_users, ds.num_items, ds.side_dim, num_classes=5)
    if os.path.exists(args.model_ckpt):
        model.load_state_dict(torch.load(args.model_ckpt, map_location="cpu"))
    model.eval()

    calib_loader = DataLoader(ds.split("calib"), batch_size=512, shuffle=False)
    test_loader  = DataLoader(ds.split("test"),  batch_size=512, shuffle=False)

    p_calib, y_calib = get_probs_and_labels(model, calib_loader)
    p_test, y_test   = get_probs_and_labels(model, test_loader)

    results = run_conformal_evaluation(p_calib, y_calib, p_test, y_test, alpha=args.alpha)
    with open(os.path.join(args.save_dir, f"rac_results_alpha{args.alpha}.json"), "w") as f:
        json.dump(results, f, indent=2)
    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    main()
