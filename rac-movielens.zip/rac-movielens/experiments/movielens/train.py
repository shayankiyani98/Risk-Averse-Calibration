
import argparse, json, os
import torch
from torch.utils.data import DataLoader
from pathlib import Path

from rac.data import MovieLensClassifDataset
from rac.models import DeepRecommenderClassifier

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", type=str, default="data/movielens")
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch_size", type=int, default=256)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--save_dir", type=str, default="artifacts/movielens")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    torch.manual_seed(args.seed)

    Path(args.save_dir).mkdir(parents=True, exist_ok=True)

    ds = MovieLensClassifDataset(root=args.data_dir)
    train_loader = DataLoader(ds.split("train"), batch_size=args.batch_size, shuffle=True)
    calib_loader = DataLoader(ds.split("calib"), batch_size=args.batch_size, shuffle=False)

    model = DeepRecommenderClassifier(ds.num_users, ds.num_items, ds.side_dim, num_classes=5)
    model = model.to("cpu")

    opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    loss_fn = torch.nn.CrossEntropyLoss()

    def run_epoch(loader, train=True):
        if train: model.train()
        else: model.eval()
        total_loss, total, correct = 0.0, 0, 0
        for batch in loader:
            x_user, x_item, x_side, y = batch
            logits = model(x_user, x_item, x_side)
            loss = loss_fn(logits, y)
            if train:
                opt.zero_grad()
                loss.backward()
                opt.step()
            total_loss += float(loss) * y.size(0)
            preds = logits.argmax(dim=1)
            correct += (preds == y).sum().item()
            total += y.size(0)
        return total_loss/total, correct/total

    for ep in range(args.epochs):
        tr_loss, tr_acc = run_epoch(train_loader, True)
        va_loss, va_acc = run_epoch(calib_loader, False)
        print(f"Epoch {ep+1}/{args.epochs} | train loss {tr_loss:.4f} acc {tr_acc:.3f} | calib loss {va_loss:.4f} acc {va_acc:.3f}")

    torch.save(model.state_dict(), os.path.join(args.save_dir, "model.pt"))
    with open(os.path.join(args.save_dir, "meta.json"), "w") as f:
        json.dump({"seed": args.seed}, f)

if __name__ == "__main__":
    main()
